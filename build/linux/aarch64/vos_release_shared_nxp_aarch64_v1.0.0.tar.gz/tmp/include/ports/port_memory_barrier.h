#ifndef PORT_MEMORY_BARRIER_H
#define PORT_MEMORY_BARRIER_H
#include "staros/so_init.h"
#ifdef __cplusplus
extern "C" {
#endif
void port_memory_barrier(void);

#ifdef __cplusplus
}
#endif
#endif