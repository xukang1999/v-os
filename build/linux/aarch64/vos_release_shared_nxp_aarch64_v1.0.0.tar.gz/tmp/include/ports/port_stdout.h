#ifndef PORT_STDOUT_H
#define PORT_STDOUT_H

#include "staros/so_init.h"
#ifdef __cplusplus
extern "C" {
#endif
SO_EXPORT int port_putchar(int c);

#ifdef __cplusplus
}
#endif
#endif