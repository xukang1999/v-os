#ifndef __PORT_PROCESS_H
#define __PORT_PROCESS_H
#include "staros/so_init.h"
#ifdef __cplusplus
extern "C" {
#endif
SO_EXPORT int port_fork(void);
#ifdef __cplusplus
}
#endif
#endif//__PORT_PROCESS_H